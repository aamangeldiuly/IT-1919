<!doctype html>
<html>
  <form action="https://www.nu.edu.kz" method="POST">
    <p>What is your favourite programming language?</p>
    <input type="text" name="languageName" id="languageId"/>
    <input type="submit"/>
  </form>
</html>
