<?php
  class week
  {
    //properties
    public $week_id;
    public $course_topic;
    public $lecture_topic;
    public $self_study;
    public $assignment;
    //method 1
    function set_week_id($week_id)
    {
      $this->week_id = $week_id;
    }
    function get_week_id()
    {
      return $this->week_id;
    }
    //method 2
    function set_course_topic($course_topic)
    {
      $this->course_topic = $course_topic;
    }
    function get_course_topic()
    {
      return $this->course_topic;
    }
  }

  $week_3 = new week();
  $week_3 -> set_week_id(3);
  $week_3 -> set_course_topic("Object-oriented Programming");
  echo "<h1>";
  echo "Web Technologies (PHP), week " . $week_3->get_week_id();
  echo "<br>";
  echo "Course Topic: " . $week_3->get_course_topic();
  echo "</h1>";
?>
