<?php
  class week
  {
    //properties
    public $week_id;
    public $course_topic;
    public $lecture_topic;
    public $self_study;
    public $assignment;
    //methods
    function set_week_id($week_id)
    {
      $this->week_id = $week_id;
    }
    function get_week_id()
    {
      return $this->week_id;
    }
  }
?>
