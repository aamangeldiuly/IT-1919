<!doctype html>
<html>
  <form action="http://localhost/lesson_3/9_2.php" method="POST" enctype="multipart/form-data">
    <p>What is your favourite programming language?</p>
    <input type="text" name="languageName" id="languageId"/>
    <p>How strong do you consider yourself in this programming language?</p>
    <input type="text" name="strengthName" id="strengthId"/>
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit"/>
  </form>
</html>
