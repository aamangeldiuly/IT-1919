<!doctype html>
<html>
<?php
  if($_POST["languageName"] || $_POST["strengthName"])
  {
    echo "I am a ".$_POST["strengthName"]." level ".$_POST["languageName"]." developer. <br>";
  }
?>
</html>
